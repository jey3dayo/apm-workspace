#!/usr/bin/env python3
"""
generate_report.py — Generate a self-contained HTML report from audit results.

Reads all analysis JSON files from the workspace and produces a standalone HTML
file with embedded data. No external dependencies required to view the report.

Usage:
    python3 generate_report.py --workspace <dir> [--output <path>]

Options:
    --workspace DIR   Directory containing analysis JSON files
    --output PATH     Output HTML file (default: <workspace>/skill-audit-report.html)
    --template PATH   HTML template file (default: auto-detect from skill dir)
"""

import json
import os
import sys
import argparse
from datetime import datetime, timezone
from pathlib import Path


def load_json_safe(filepath: str) -> dict | list | None:
    """Load a JSON file, returning None if it doesn't exist or fails."""
    if not os.path.isfile(filepath):
        return None
    try:
        with open(filepath, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception as e:
        print(f"WARNING: Could not load {filepath}: {e}", file=sys.stderr)
        return None


def find_template() -> str | None:
    """Find the HTML template relative to this script's location."""
    script_dir = Path(__file__).resolve().parent.parent
    template = script_dir / "assets" / "report_template.html"
    if template.is_file():
        return str(template)
    return None


def generate_report(workspace: str, template_path: str | None = None) -> str:
    """Generate HTML report from workspace data.

    Returns the HTML string.
    """
    # Load all analysis results
    audit_report = load_json_safe(os.path.join(workspace, "audit-report.json"))
    portfolio = load_json_safe(os.path.join(workspace, "portfolio-analysis.json"))
    proposals = load_json_safe(os.path.join(workspace, "improvement-proposals.json"))
    manifest = load_json_safe(os.path.join(workspace, "skill-manifest.json"))
    history = load_json_safe(os.path.join(workspace, "health-history.json"))

    # Build embedded data object
    data = {
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "audit_report": audit_report,
        "portfolio_analysis": portfolio,
        "improvement_proposals": proposals,
        "skill_manifest": manifest,
        "health_history": history or [],
    }

    # Load template
    if template_path and os.path.isfile(template_path):
        with open(template_path, "r", encoding="utf-8") as f:
            html = f.read()
    else:
        # Use built-in minimal template
        html = _builtin_template()

    # Inject data
    json_data = json.dumps(data, indent=2, ensure_ascii=False, default=str)
    html = html.replace("/*__EMBEDDED_DATA__*/", f"const REPORT_DATA = {json_data};")

    return html


def _builtin_template() -> str:
    """Fallback template if assets/report_template.html is not found."""
    return """<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Skill Audit Report</title>
<style>
  :root {
    --bg: #faf9f5; --fg: #141413; --accent: #d97757;
    --success: #788c5d; --error: #c44; --info: #6a9bcc;
    --border: #e0ddd8; --card-bg: #fff; --muted: #666;
  }
  * { margin: 0; padding: 0; box-sizing: border-box; }
  body { font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    background: var(--bg); color: var(--fg); line-height: 1.6; padding: 2rem; max-width: 1200px; margin: 0 auto; }
  h1 { font-size: 1.8rem; margin-bottom: 0.5rem; }
  h2 { font-size: 1.3rem; margin: 2rem 0 1rem; border-bottom: 2px solid var(--accent); padding-bottom: 0.3rem; }
  h3 { font-size: 1.1rem; margin: 1rem 0 0.5rem; }
  .meta { color: var(--muted); font-size: 0.85rem; margin-bottom: 2rem; }
  .grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(280px, 1fr)); gap: 1rem; }
  .card { background: var(--card-bg); border: 1px solid var(--border); border-radius: 8px; padding: 1rem; }
  .card-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 0.5rem; }
  .badge { display: inline-block; padding: 2px 8px; border-radius: 12px; font-size: 0.75rem; font-weight: 600; }
  .badge-good { background: #e8f0e0; color: var(--success); }
  .badge-warn { background: #fef3e0; color: #b8860b; }
  .badge-bad { background: #fde8e8; color: var(--error); }
  .badge-info { background: #e8f0f8; color: var(--info); }
  .stat { display: inline-block; margin-right: 1rem; }
  .stat-value { font-size: 1.4rem; font-weight: 700; }
  .stat-label { font-size: 0.75rem; color: var(--muted); }
  .summary-bar { display: flex; gap: 2rem; flex-wrap: wrap; margin: 1rem 0; }
  table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.9rem; }
  th, td { padding: 0.5rem 0.75rem; text-align: left; border-bottom: 1px solid var(--border); }
  th { font-weight: 600; background: #f5f4f0; }
  .incident { background: #fff8f0; border-left: 3px solid var(--accent); padding: 0.5rem 0.75rem; margin: 0.5rem 0; border-radius: 0 4px 4px 0; font-size: 0.85rem; }
  .incident-fp { border-left-color: var(--error); background: #fff5f5; }
  .incident-fn { border-left-color: #b8860b; background: #fffcf0; }
  .incident-confused { border-left-color: var(--info); background: #f5f8ff; }
  .diff { font-family: monospace; font-size: 0.8rem; background: #f8f8f5; padding: 0.75rem; border-radius: 4px; margin: 0.5rem 0; white-space: pre-wrap; word-break: break-word; }
  .diff-add { color: var(--success); }
  .diff-del { color: var(--error); text-decoration: line-through; }
  .matrix-cell { width: 24px; height: 24px; display: inline-block; border-radius: 4px; }
  .matrix-orthogonal { background: #e8f0e0; }
  .matrix-adjacent { background: #fef3e0; }
  .matrix-overlapping { background: #fde8e8; }
  .matrix-nested { background: #e8f0f8; }
  .empty { text-align: center; color: var(--muted); padding: 2rem; font-style: italic; }
  details { margin: 0.5rem 0; }
  summary { cursor: pointer; font-weight: 500; }
  .token-bar { height: 8px; border-radius: 4px; background: var(--border); margin: 4px 0; }
  .token-bar-fill { height: 100%; border-radius: 4px; background: var(--accent); }
  footer { margin-top: 3rem; padding-top: 1rem; border-top: 1px solid var(--border); color: var(--muted); font-size: 0.8rem; text-align: center; }
</style>
</head>
<body>
<h1>Skill Audit Report</h1>
<div class="meta" id="meta"></div>

<div class="summary-bar" id="summary-bar"></div>

<h2>Per-Skill Health</h2>
<div id="skill-cards"></div>

<h2>Competition Matrix</h2>
<div id="competition-matrix"></div>

<h2>Attention Budget</h2>
<div id="attention-budget"></div>

<h2>Improvement Patches</h2>
<div id="patches"></div>

<h2>Coverage Gaps</h2>
<div id="coverage-gaps"></div>

<h2>New Skill Proposals</h2>
<div id="new-skills"></div>

<footer>Generated by skill-auditor</footer>

<script>
/*__EMBEDDED_DATA__*/

document.addEventListener('DOMContentLoaded', () => {
  if (typeof REPORT_DATA === 'undefined') {
    document.body.innerHTML = '<div class="empty">No data loaded. Run the audit first.</div>';
    return;
  }

  const d = REPORT_DATA;
  const audit = d.audit_report || {};
  const portfolio = d.portfolio_analysis || {};
  const proposals = d.improvement_proposals || {};
  const manifest = d.skill_manifest || {};

  // Meta
  const meta = audit.meta || {};
  document.getElementById('meta').innerHTML =
    `Generated: ${new Date(d.generated_at).toLocaleString()} | ` +
    `Sessions: ${meta.sessions_analyzed || '?'} | ` +
    `Turns: ${meta.turns_analyzed || '?'} | ` +
    `Skills: ${meta.skills_in_scope || '?'}`;

  // Summary bar
  const health = portfolio.portfolio_health || {};
  const healthBadge = {
    'healthy': 'badge-good', 'needs_attention': 'badge-warn', 'critical': 'badge-bad'
  }[health.overall_score] || 'badge-info';

  document.getElementById('summary-bar').innerHTML = `
    <div class="stat">
      <div class="stat-value"><span class="badge ${healthBadge}">${health.overall_score || '?'}</span></div>
      <div class="stat-label">Portfolio Health</div>
    </div>
    <div class="stat">
      <div class="stat-value">${health.routing_accuracy_avg != null ? (health.routing_accuracy_avg * 100).toFixed(0) + '%' : '?'}</div>
      <div class="stat-label">Avg Accuracy</div>
    </div>
    <div class="stat">
      <div class="stat-value">${health.competition_conflicts || 0}</div>
      <div class="stat-label">Conflicts</div>
    </div>
    <div class="stat">
      <div class="stat-value">${health.coverage_gaps || 0}</div>
      <div class="stat-label">Gaps</div>
    </div>
    <div class="stat">
      <div class="stat-value">${(portfolio.attention_budget || {}).total_tokens || '?'}</div>
      <div class="stat-label">Total Desc Tokens</div>
    </div>
  `;

  // Skill cards — grouped by scope
  const reports = audit.skill_reports || [];
  const neverFired = audit.skills_never_fired || [];
  const manifestSkills = (manifest.skills || []);
  const scopeMap = {};
  for (const ms of manifestSkills) {
    scopeMap[ms.name] = { scope: ms.scope || 'global', project_path: ms.project_path || null };
  }

  function renderCard(r) {
    const s = r.stats || {};
    const acc = s.accuracy != null ? (s.accuracy * 100).toFixed(0) : '?';
    const accClass = s.accuracy >= 0.9 ? 'badge-good' : s.accuracy >= 0.7 ? 'badge-warn' : 'badge-bad';
    let incidentsHtml = '';
    for (const inc of (r.incidents || []).slice(0, 5)) {
      const cls = inc.verdict === 'false_positive' ? 'incident-fp' :
                  inc.verdict === 'false_negative' ? 'incident-fn' : 'incident-confused';
      incidentsHtml += `<div class="incident ${cls}"><strong>${inc.verdict}</strong>: ${esc(inc.detail)}<br><em>"${esc((inc.user_message || '').substring(0, 100))}"</em></div>`;
    }
    const skillPath = r.skill_path || (scopeMap[r.skill_name] || {}).filepath || '';
    return `<div class="card">
      <div class="card-header"><h3>${esc(r.skill_name)}</h3><span class="badge ${accClass}">${acc}%</span></div>
      ${skillPath ? `<div style="font-size:0.7rem;color:var(--muted);margin-bottom:4px;word-break:break-all">${esc(skillPath)}</div>` : ''}
      <div style="font-size:0.85rem;color:var(--muted);margin-bottom:0.5rem">${esc(r.description_excerpt || '')}</div>
      <div style="font-size:0.85rem">Fires: ${s.total_fires || 0} | FP: ${s.false_positives || 0} | FN: ${s.false_negatives || 0}</div>
      <div style="margin-top:0.5rem;font-size:0.85rem">${esc(r.health_assessment || '')}</div>
      ${incidentsHtml ? `<details><summary>Incidents (${(r.incidents||[]).length})</summary>${incidentsHtml}</details>` : ''}
      ${r.suggested_fix ? `<div style="margin-top:0.5rem;font-size:0.8rem;color:var(--accent)"><strong>Fix:</strong> ${esc(r.suggested_fix)}</div>` : ''}
    </div>`;
  }
  function renderNeverFired(nf) {
    return `<div class="card" style="opacity:0.6">
      <div class="card-header"><h3>${esc(nf.skill_name)}</h3><span class="badge badge-info">never fired</span></div>
      <div style="font-size:0.85rem">${esc(nf.reason || '')}</div>
    </div>`;
  }

  const globalReports = [], projectReports = {};
  for (const r of reports) {
    const info = scopeMap[r.skill_name];
    if (info && info.scope === 'project-local' && info.project_path) {
      (projectReports[info.project_path] = projectReports[info.project_path] || []).push(r);
    } else { globalReports.push(r); }
  }
  const globalNF = [], projectNF = {};
  for (const nf of neverFired) {
    const info = scopeMap[nf.skill_name];
    if (info && info.scope === 'project-local' && info.project_path) {
      (projectNF[info.project_path] = projectNF[info.project_path] || []).push(nf);
    } else { globalNF.push(nf); }
  }

  let allCardsHtml = '<h3 style="margin:1rem 0 0.5rem">Global Skills</h3><div class="grid">';
  for (const r of globalReports) allCardsHtml += renderCard(r);
  for (const nf of globalNF) allCardsHtml += renderNeverFired(nf);
  if (!globalReports.length && !globalNF.length) allCardsHtml += '<div class="empty">No global skill data</div>';
  allCardsHtml += '</div>';

  const allProjects = [...new Set([...Object.keys(projectReports), ...Object.keys(projectNF)])].sort();
  for (const pp of allProjects) {
    const projName = pp.split('/').filter(Boolean).pop() || pp;
    allCardsHtml += `<h3 style="margin:1.5rem 0 0.5rem">Project: ${esc(projName)} <span style="font-size:0.75rem;color:var(--muted);font-weight:normal">${esc(pp)}</span></h3><div class="grid">`;
    for (const r of (projectReports[pp]||[])) allCardsHtml += renderCard(r);
    for (const nf of (projectNF[pp]||[])) allCardsHtml += renderNeverFired(nf);
    allCardsHtml += '</div>';
  }

  document.getElementById('skill-cards').innerHTML = allCardsHtml || '<div class="empty">No skill data</div>';

  // Competition matrix
  const matrix = (portfolio.competition_matrix || []).filter(m => m.relationship !== 'orthogonal');
  if (matrix.length) {
    let matrixHtml = '<table><tr><th>Skill A</th><th>Skill B</th><th>Relationship</th><th>Boundary</th><th>Fix?</th></tr>';
    for (const m of matrix) {
      const relClass = `matrix-${m.relationship}`;
      matrixHtml += `<tr>
        <td>${esc(m.skill_a)}</td><td>${esc(m.skill_b)}</td>
        <td><span class="matrix-cell ${relClass}"></span> ${m.relationship}</td>
        <td style="font-size:0.85rem">${esc(m.boundary || '')}</td>
        <td>${m.coordinated_fix_needed ? '<span class="badge badge-warn">yes</span>' : 'no'}</td>
      </tr>`;
    }
    matrixHtml += '</table>';
    document.getElementById('competition-matrix').innerHTML = matrixHtml;
  } else {
    document.getElementById('competition-matrix').innerHTML = '<div class="empty">No competition conflicts detected</div>';
  }

  // Attention budget
  const budget = (portfolio.attention_budget || {}).per_skill || [];
  if (budget.length) {
    const maxTok = Math.max(...budget.map(b => b.description_tokens || 0), 1);
    let budgetHtml = '<table><tr><th>Skill</th><th>Tokens</th><th>Share</th><th>Fires</th><th>Efficiency</th><th></th></tr>';
    for (const b of budget.sort((a,b) => (b.description_tokens||0) - (a.description_tokens||0))) {
      const effClass = b.efficiency_rating === 'efficient' ? 'badge-good' :
                       b.efficiency_rating === 'bloated' ? 'badge-bad' :
                       b.efficiency_rating === 'unused' ? 'badge-warn' : 'badge-info';
      const pct = ((b.description_tokens || 0) / maxTok * 100).toFixed(0);
      budgetHtml += `<tr>
        <td>${esc(b.skill_name)}</td>
        <td>${b.description_tokens || 0}</td>
        <td>${(b.budget_share_pct || 0).toFixed(1)}%</td>
        <td>${b.fires_in_audit || 0}</td>
        <td><span class="badge ${effClass}">${b.efficiency_rating || '?'}</span></td>
        <td style="width:120px"><div class="token-bar"><div class="token-bar-fill" style="width:${pct}%"></div></div></td>
      </tr>`;
    }
    budgetHtml += '</table>';
    document.getElementById('attention-budget').innerHTML = budgetHtml;
  } else {
    document.getElementById('attention-budget').innerHTML = '<div class="empty">No attention budget data</div>';
  }

  // Patches
  const patches = proposals.patches || [];
  if (patches.length) {
    let patchHtml = '';
    for (const p of patches) {
      const prioClass = p.priority === 'high' ? 'badge-bad' : p.priority === 'medium' ? 'badge-warn' : 'badge-info';
      patchHtml += `<div class="card" style="margin-bottom:1rem">
        <div class="card-header">
          <h3>${esc(p.skill_name)}</h3>
          <span class="badge ${prioClass}">${p.priority}</span>
        </div>
        <div style="font-size:0.85rem;margin-bottom:0.5rem"><strong>Fixes:</strong> ${(p.fixes_issues||[]).map(esc).join(', ')}</div>
        <div style="font-size:0.85rem;margin-bottom:0.5rem"><strong>Changes:</strong> ${(p.changes_made||[]).map(esc).join('; ')}</div>
        <div class="diff"><span class="diff-del">${esc(p.current_description || '')}</span>\n<span class="diff-add">${esc(p.proposed_description || '')}</span></div>
        <div style="font-size:0.8rem;color:var(--muted);margin-top:0.5rem">
          Cascade risk: ${esc(p.cascade_risk || '?')} |
          Token delta: ${p.token_delta > 0 ? '+' : ''}${p.token_delta || 0}
          ${p.coordinated_with ? ` | Coordinated with: ${esc(p.coordinated_with)}` : ''}
        </div>
      </div>`;
    }
    document.getElementById('patches').innerHTML = patchHtml;
  } else {
    document.getElementById('patches').innerHTML = '<div class="empty">No patches proposed</div>';
  }

  // Coverage gaps
  const gaps = audit.coverage_gaps || [];
  if (gaps.length) {
    let gapHtml = '<table><tr><th>Unmet Intent</th><th>Frequency</th><th>Suggestion</th></tr>';
    for (const g of gaps) {
      gapHtml += `<tr><td>${esc(g.unmet_intent)}</td><td>${g.frequency}</td><td>${esc(g.suggestion || '')}</td></tr>`;
    }
    gapHtml += '</table>';
    document.getElementById('coverage-gaps').innerHTML = gapHtml;
  } else {
    document.getElementById('coverage-gaps').innerHTML = '<div class="empty">No coverage gaps detected</div>';
  }

  // New skill proposals
  const newSkills = proposals.new_skill_suggestions || [];
  if (newSkills.length) {
    let nsHtml = '';
    for (const ns of newSkills) {
      nsHtml += `<div class="card" style="margin-bottom:1rem">
        <h3>${esc(ns.suggested_name)}</h3>
        <div style="font-size:0.85rem;margin:0.5rem 0">${esc(ns.rationale)}</div>
        <div class="diff">${esc(ns.suggested_description || '')}</div>
        <div style="font-size:0.8rem;color:var(--muted);margin-top:0.5rem">
          Coverage: ${ns.coverage_gap_incidents || 0} incidents |
          Overlap risk: ${esc(ns.overlap_risk || '?')}
        </div>
      </div>`;
    }
    document.getElementById('new-skills').innerHTML = nsHtml;
  } else {
    document.getElementById('new-skills').innerHTML = '<div class="empty">No new skills suggested</div>';
  }
});

function esc(s) { return String(s || '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;'); }
</script>
</body>
</html>"""


def main():
    parser = argparse.ArgumentParser(
        description="Generate HTML skill audit report"
    )
    parser.add_argument(
        "--workspace", required=True,
        help="Directory containing analysis JSON files",
    )
    parser.add_argument(
        "--output", default=None,
        help="Output HTML file (default: <workspace>/skill-audit-report.html)",
    )
    parser.add_argument(
        "--template", default=None,
        help="HTML template file (default: auto-detect)",
    )

    args = parser.parse_args()

    if not os.path.isdir(args.workspace):
        print(f"ERROR: Workspace not found: {args.workspace}", file=sys.stderr)
        sys.exit(1)

    template = args.template or find_template()
    if args.output:
        output = args.output
    else:
        output = os.path.join(args.workspace, "skill-audit-report.html")

    html = generate_report(args.workspace, template)

    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    with open(output, "w", encoding="utf-8") as f:
        f.write(html)

    print(f"Report generated: {output}")


if __name__ == "__main__":
    main()
