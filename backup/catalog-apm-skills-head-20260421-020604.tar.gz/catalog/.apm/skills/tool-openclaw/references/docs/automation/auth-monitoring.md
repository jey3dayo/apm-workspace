<!-- SNAPSHOT: source_url=https://docs.openclaw.ai/automation/auth-monitoring.md; fetched_at=2026-02-20T10:29:12.579Z; sha256=b014a834a380ac3088fa7e4ccc1dafa94cc664a8d08454d731b99b063af44f28; content_type=text/markdown; charset=utf-8; status=ok -->

> ## Documentation Index
> Fetch the complete documentation index at: https://docs.openclaw.ai/llms.txt
> Use this file to discover all available pages before exploring further.

# Auth Monitoring

# Auth monitoring

OpenClaw exposes OAuth expiry health via `openclaw models status`. Use that for
automation and alerting; scripts are optional extras for phone workflows.

## Preferred: CLI check (portable)

```bash  theme={"theme":{"light":"min-light","dark":"min-dark"}}
openclaw models status --check
```

Exit codes:

* `0`: OK
* `1`: expired or missing credentials
* `2`: expiring soon (within 24h)

This works in cron/systemd and requires no extra scripts.

## Optional scripts (ops / phone workflows)

These live under `scripts/` and are **optional**. They assume SSH access to the
gateway host and are tuned for systemd + Termux.

* `scripts/claude-auth-status.sh` now uses `openclaw models status --json` as the
  source of truth (falling back to direct file reads if the CLI is unavailable),
  so keep `openclaw` on `PATH` for timers.
* `scripts/auth-monitor.sh`: cron/systemd timer target; sends alerts (ntfy or phone).
* `scripts/systemd/openclaw-auth-monitor.{service,timer}`: systemd user timer.
* `scripts/claude-auth-status.sh`: Claude Code + OpenClaw auth checker (full/json/simple).
* `scripts/mobile-reauth.sh`: guided re‑auth flow over SSH.
* `scripts/termux-quick-auth.sh`: one‑tap widget status + open auth URL.
* `scripts/termux-auth-widget.sh`: full guided widget flow.
* `scripts/termux-sync-widget.sh`: sync Claude Code creds → OpenClaw.

If you don’t need phone automation or systemd timers, skip these scripts.
