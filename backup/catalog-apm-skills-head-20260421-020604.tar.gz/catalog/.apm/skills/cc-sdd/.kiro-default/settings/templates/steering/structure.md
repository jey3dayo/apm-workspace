# Project Structure

## Organization Philosophy

[Describe approach: feature-first, layered, domain-driven, etc.]

## Directory Patterns

### [Pattern Name]

### Location

### Example

### [Pattern Name]

### Location

### Example

## Naming Conventions

- Files: [Pattern, e.g., PascalCase, kebab-case]
- Components: [Pattern]
- Functions: [Pattern]

## Import Organization

```typescript
// Example import patterns
import { Something } from "@/path"; // Absolute
import { Local } from "./local"; // Relative
```

### Path Aliases

- `@/`: [Maps to]

## Code Organization Principles

[Key architectural patterns and dependency rules]

---

Document patterns, not file trees. New files following patterns should not require updates.
