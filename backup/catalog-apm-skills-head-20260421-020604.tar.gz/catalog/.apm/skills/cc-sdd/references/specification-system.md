# Specification システム詳細

Specificationシステムは、個別機能の開発プロセスを形式化する仕組みです。

## Specification とは

### Specification

### Specification の目的

1. 要件の明確化: 何を作るのかを明確に定義
2. 設計の文書化: どのように作るのかを技術的に設計
3. タスクの分解: 実装を管理可能な作業単位に分割
4. 進捗の追跡: 機能開発の状態を可視化
5. 品質の保証: 段階的な承認により品質を担保

## ディレクトリ構造

```
.kiro/specs/
└── [feature-name]/              # 機能ごとのディレクトリ
    ├── spec.json                # メタデータと承認追跡
    ├── requirements.md          # 要件定義（EARS形式）
    ├── design.md                # 技術設計
    └── tasks.md                 # 実装タスク
```

### ディレクトリ命名規則

機能名は以下のように生成されます：

- ケバブケース: `user-authentication`, `payment-processing`
- 簡潔で説明的: 機能の本質を捉える
- 重複チェック: 既存の仕様との衝突を回避
- 連番サフィックス: 重複時は `-2`, `-3` を追加

## spec.json - メタデータ管理

spec.jsonは仕様の状態と進捗を追跡します。

### 構造

```json
{
  "feature_name": "user-authentication",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-16T14:45:00Z",
  "language": "ja",
  "phase": "design-generated",
  "approvals": {
    "requirements": {
      "generated": true,
      "approved": true
    },
    "design": {
      "generated": true,
      "approved": false
    },
    "tasks": {
      "generated": false,
      "approved": false
    }
  },
  "ready_for_implementation": false
}
```

### フィールド説明

#### feature_name

- 機能の一意な識別子
- ファイル名やコマンドで使用

#### created_at / updated_at

- ISO8601形式のタイムスタンプ
- 作成日時と最終更新日時を記録

#### language

- ドキュメントの言語（`ja` または `en`）
- 生成されるドキュメントの言語を決定

#### phase

現在のフェーズを示す：

- `initialized` - 初期化済み、requirements未生成
- `requirements-generated` - 要件生成済み、未承認
- `design-generated` - 設計生成済み、未承認
- `tasks-generated` - タスク生成済み、未承認
- `implementation-ready` - すべて承認済み、実装可能

#### approvals

各フェーズの生成と承認状態を追跡：

- `generated`: ドキュメントが生成されたか
- `approved`: 人間による承認を得たか

#### ready_for_implementation

すべてのフェーズが承認され、実装を開始できる状態か。

## requirements.md - 要件定義

EARS（Easy Approach to Requirements Syntax）形式で要件を定義します。

### ドキュメント構造

```markdown
# Requirements Document

## Introduction

[機能の概要とビジネス価値]

## Requirements

### Requirement 1: [主要目的領域]

**Objective:** As a [役割/ステークホルダー], I want [機能/能力/成果], so that [利点]

#### Acceptance Criteria

1. WHEN [イベント] THEN [システム/主語] SHALL [応答]
2. IF [前提条件] THEN [システム/主語] SHALL [応答]
3. WHILE [継続条件] THE [システム/主語] SHALL [継続動作]
4. WHERE [場所/コンテキスト] THE [システム/主語] SHALL [文脈動作]

### Requirement 2: [次の主要目的領域]

...
```

### EARS形式

詳細は `@ears-format.md` を参照。

主要パターン：

- WHEN...THEN: イベント駆動の要件
- IF...THEN: 条件付き要件
- WHILE...THE: 継続的な動作
- WHERE...THE: 文脈依存の動作

### 要件カバレッジ

すべての要件は：

- ID番号を持つ（1.1, 1.2, 2.1など）
- 明確な受入基準を持つ
- テスト可能である
- 後のフェーズで追跡される

## design.md - 技術設計

要件に基づいて技術的な設計を文書化します。

### ドキュメント構造

```markdown
# Technical Design

## Overview

[目的、ユーザー、影響]

### Goals

[主要な目標]

### Non-Goals

[明示的に除外される機能]

## Architecture

[高レベルアーキテクチャ、Mermaid図]

### Technology Stack and Design Decisions

[技術選択と主要な設計決定]

## System Flows

[シーケンス図、プロセスフロー]

## Requirements Traceability

[要件からコンポーネントへのマッピング]

## Components and Interfaces

[各コンポーネントの詳細]

## Data Models

[ドメインモデル、論理/物理データモデル]

## Error Handling

[エラー戦略とカテゴリ]

## Testing Strategy

[ユニット、統合、E2Eテスト]

## Security Considerations (該当する場合)

## Performance & Scalability (該当する場合)

## Migration Strategy (該当する場合)
```

### 設計原則

- レビュー最適化構造: 重要な技術決定を目立つ場所に配置
- 文脈的関連性: プロジェクトタイプとスコープに応じたセクション
- ビジュアルファースト設計: 必須のMermaid図
- 設計のみに焦点: アーキテクチャとインターフェース、実装コードなし
- 型安全性: `any`型を使用しない
- 形式的トーン: 断定的な記述、曖昧な表現を避ける

## tasks.md - 実装タスク

設計を実行可能なタスクに分解します。

### ドキュメント構造

```markdown
# Implementation Plan

- [ ] 1. プロジェクト基盤とインフラのセットアップ
  - 必要な技術スタックでプロジェクトを初期化
  - サーバーインフラとリクエスト処理を設定
  - データストレージとキャッシュ層を確立
  - 設定と環境管理をセットアップ
  - _Requirements: すべての要件に基礎セットアップが必要_

- [ ] 2. 認証とユーザー管理システムの構築
- [ ] 2.1 コア認証機能の実装
  - 検証ルールを含むユーザーデータストレージをセットアップ
  - 安全な認証メカニズムを実装
  - ユーザー登録機能を構築
  - ログインとセッション管理機能を追加
  - _Requirements: 7.1, 7.2_

- [ ] 2.2 メールサービス統合の有効化
  - 安全な認証情報ストレージシステムを実装
  - メールプロバイダー向け認証フローを構築
  - メール接続検証ロジックを作成
  - メールアカウント管理機能を開発
  - _Requirements: 5.1, 5.2, 5.4_
```

### タスク番号付けルール（必須）

### 絶対に守る

- メジャータスク: 1, 2, 3, 4, 5...（連番）
- サブタスク: 1.1, 1.2, 2.1, 2.2...（メジャータスクごとにリセット）
- 最大2レベルの階層（1.1.1以降は禁止）

### タスク生成ルール

1. 自然言語の説明
   - 機能と成果に焦点
   - コード構造ではない
   - ドメイン言語を使用

2. タスクの統合と進行
   - 各タスクは前の出力に基づく
   - 統合タスクで結合
   - 孤立したコードなし

3. 柔軟なタスクサイズ
   - サブタスク: 1-3時間
   - 詳細: 3-10項目
   - 凝集性でグループ化

4. 要件マッピング
   - 詳細の末尾に `_Requirements: X.X, Y.Y_`

5. コードのみに焦点
   - コーディング/テストタスクのみ
   - デプロイ/ドキュメント/ユーザーテストは除外

## 3段階承認ワークフロー

Specificationシステムの核心は、段階的な承認プロセスです。

### なぜ承認が必要か

1. 方向性の確認: 間違った方向への進行を防ぐ
2. 理解の検証: 要件の解釈を確認
3. 品質の保証: 各段階で品質をチェック
4. リスクの低減: 実装前に問題を発見

### 承認プロセス

#### Phase 1: Requirements承認

### 生成

### レビューポイント

- 要件は明確か
- 受入基準は測定可能か
- すべての機能がカバーされているか
- EARS形式が正しく使われているか

### 承認方法

- 修正が不要な場合: `/kiro:spec-design [feature-name] -y`
- 修正が必要な場合: 変更を要求し、再生成

#### Phase 2: Design承認

### 生成

### レビューポイント

- アーキテクチャは適切か
- 技術選択は正当化されているか
- すべての要件が設計でカバーされているか
- リスクは適切に対処されているか

### 承認方法

- 修正が不要な場合: `/kiro:spec-tasks [feature-name] -y`
- 修正が必要な場合: 変更を要求し、再生成

#### Phase 3: Tasks承認

### 生成

### レビューポイント

- タスクサイズは適切か（1-3時間）
- すべての要件がタスクでカバーされているか
- タスクの依存関係は正しいか
- 技術選択は設計と一致しているか

### 承認方法

- 修正が不要な場合: 実装を開始
- 修正が必要な場合: 変更を要求し、再生成

### 自動承認フラグ（`-y`）

各コマンドは `-y` フラグで前フェーズを自動承認できます：

- `/kiro:spec-design [feature-name] -y`: requirements を自動承認して design 生成
- `/kiro:spec-tasks [feature-name] -y`: requirements と design を自動承認して tasks 生成

### 使用時の注意

- 前フェーズの内容を確認済みの場合のみ使用
- ワークフローを高速化するが、レビューをスキップしない

## フェーズスキップの禁止

各フェーズは前フェーズの承認を必須とします：

```
spec-init
    ↓
requirements (生成) → 承認必須
    ↓
design (生成) → 承認必須
    ↓
tasks (生成) → 承認必須
    ↓
implementation
```

### 理由

- 設計は承認済み要件に基づく
- タスクは承認済み設計に基づく
- 実装は承認済みタスクに基づく
- 一貫性と品質を維持

## タスクステータスの更新

実装中は tasks.md のチェックボックスを更新：

- `- [ ]`: 未完了
- `- [x]`: 完了

### 更新タイミング

- タスク開始時
- タスク完了時
- ブロックされた場合

### `/kiro:spec-status` での追跡

- チェックボックスの状態を解析
- 完了率を計算
- 次の未完了タスクを特定

## アクティブな仕様の管理

### 仕様の一覧

```bash
ls -la .kiro/specs/
```

各ディレクトリが1つの機能を表します。

### 仕様のステータス確認

```bash
/kiro:spec-status [feature-name]
```

包括的なステータスレポートを表示：

- 仕様概要
- フェーズステータス
- 実装進捗
- 品質メトリクス
- 推奨事項
- ステアリング整合性

### 複数の仕様

同時に複数の仕様を管理できます：

```
.kiro/specs/
├── user-authentication/
├── payment-processing/
└── notification-system/
```

各仕様は独立して進行できます。

## ベストプラクティス

### 仕様の作成

1. 詳細な説明から始める: spec-init に十分な情報を提供
2. 要件を明確にする: EARS形式で具体的に
3. 設計を徹底する: アーキテクチャと技術決定を文書化
4. タスクを適切なサイズに: 1-3時間の作業単位

### 仕様の管理

1. ステータスを定期的に確認: `/kiro:spec-status` で進捗を追跡
2. タスクステータスを更新: 完了したタスクをマーク
3. 承認を真剣に: 各フェーズを慎重にレビュー
4. ステアリングと整合: プロジェクト基準に従う

### トラブルシューティング

1. 要件が不明確: `/kiro:spec-requirements` を再実行
2. 設計が複雑すぎる: 小さな機能に分割
3. タスクが大きすぎる: より細かいサブタスクに分割
4. ギャップを発見: `/kiro:validate-gap` で分析

## まとめ

Specificationシステムは、機能開発を構造化された段階的なプロセスに変換します。要件、設計、タスクを明確に文書化し、各段階で承認を得ることで、品質の高い実装を実現します。
